<?php
$folderUpload = "../uploads";
$file = (object) @$_FILES['filename'];
if ($file->size > 300) {
  echo '<script>alert("under 1 KB only!")</script>';
  die();
}
if ($file->type !== 'image/jpeg') {
  echo '<script>alert("image only!")</script>';
  die();
}
$uploadSukses = move_uploaded_file(
  $file->tmp_name, "{$folderUpload}/{$file->name}"
);

?>